const Engine = Matter.Engine;
const World = Matter.World;
const Bodies = Matter.Bodies;
const Constraint = Matter.Constraint;

var engine, world;
var canvas;
var playerBase;
var computerBase;
var computerPlayer;
var player;


function setup() {
  canvas = createCanvas(1500, 900);
  
   //Initialising Engine
  engine = Engine.create();
  world = engine.world;
	
   //Create Player Base and Computer Base Object
  playerBase = new PlayerBase(200,450,180,150);
  computerBase = new ComputerBase(1000,0,180,150);
  player = new Player(-1000,-140,50,180);
  computerPlayer = new ComputerPlayer(1000,0,50,180);
 }

function draw() {

  background(180);

  Engine.update(engine);

  // Title
  fill("#FFFF");
  textAlign("center");
  textSize(40);
  text("EPIC ARCHERY", width / 2, 100);

   //Display Playerbase and computer base 
  playerBase.display();
  computerBase.display();

   //display Player and computerplayer
  player.display();
  computerPlayer.display();

}
